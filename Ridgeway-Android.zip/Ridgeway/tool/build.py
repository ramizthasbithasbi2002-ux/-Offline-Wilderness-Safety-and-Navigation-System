"""Build Android with a configured Flutter SDK and Android toolchain."""
import urllib.request
import pathlib, subprocess, tempfile, shutil, os
root = pathlib.Path(__file__).resolve().parents[1]
flutter = shutil.which('flutter')
if not flutter: raise SystemExit('Install Flutter and Android SDK first (flutter doctor).')
with tempfile.TemporaryDirectory() as temp:
    app = pathlib.Path(temp)/'ridgeway'
    def run(*args, cwd=app):
        subprocess.run([flutter,*args],cwd=cwd,check=True,shell=os.name=='nt')
    run('create','--platforms=android','--project-name','ridgeway',str(app),cwd=temp)
    for folder in ['lib','assets']: shutil.copytree(root/folder,app/folder,dirs_exist_ok=True)
    for ext in ['js','css']:
        urllib.request.urlretrieve('https://unpkg.com/maplibre-gl@4.7.1/dist/maplibre-gl.'+ext,app/'assets'/('maplibre.'+ext))
    shutil.copy(root/'pubspec.yaml',app)
    manifest = app/'android/app/src/main/AndroidManifest.xml'
    manifest.write_text(manifest.read_text().replace('<application','<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/><uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION"/><uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/><uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/><uses-permission android:name="android.permission.INTERNET"/><application',1))
    run('pub','get')
    run('analyze','lib','--no-fatal-infos','--no-fatal-warnings')
    run('build','apk','--release')
    shutil.copy(app/'build/app/outputs/flutter-apk/app-release.apk',root/'Ridgeway.apk')
