import 'dart:async';
import 'download.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as m;
import 'package:collection/collection.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sqflite/sqflite.dart';

void main()=>runApp(MaterialApp(title:'Ridgeway',debugShowCheckedModeBanner:false,theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:const Color(0xff23594c)),useMaterial3:true),home:const Field()));
typedef Point = ({double lat,double lon});
double distance(Point a,Point b)=>Geolocator.distanceBetween(a.lat,a.lon,b.lat,b.lon);
class Region {
 final Map data;
 Region(this.data){
  if(rows<2||cols<2||rows*cols>100000||step<=0||step>.02||z.any((r)=>r.length!=cols||r.any((v)=>v is! num)))throw const FormatException('Invalid elevation grid');
  if(exits.isEmpty||[...exits,...blocked,...water.map((v)=>v['cell'] as int)].any((i)=>i<0||i>=rows*cols))throw const FormatException('Invalid features');
 }
 List get z=>data['z']; int get rows=>z.length; int get cols=>z.first.length;
 double get step=>(data['step'] as num).toDouble();
 late final blocked=Set<int>.from(data['blocked']);late final exits=Set<int>.from(data['exits']);List get water=>data['water'];
 Point point(int i)=>(lat:(data['lat'] as num).toDouble()+(i~/cols)*step,lon:(data['lon'] as num).toDouble()+(i%cols)*step);
 int? cell(Point p){final x=((p.lon-data['lon'])/step).round(),y=((p.lat-data['lat'])/step).round();return x<0||y<0||x>=cols||y>=rows?null:y*cols+x;}
 List<int> route(int start){
  if(blocked.contains(start))return [];
  final costs={start:0.0},parent=<int,int>{},done=<int>{};
  final queue=PriorityQueue<(int,double)>((a,b)=>a.$2.compareTo(b.$2))..add((start,0));
  while(queue.isNotEmpty){final i=queue.removeFirst().$1;if(!done.add(i))continue;
   if(exits.contains(i)){final result=[i];while(parent.containsKey(result.last)){result.add(parent[result.last]!);}return result.reversed.toList();}
   final x=i%cols,y=i~/cols;
   for(final d in [(0,1),(0,-1),(1,0),(-1,0)]){final a=x+d.$1,b=y+d.$2;if(a<0||b<0||a>=cols||b>=rows)continue;
    final j=b*cols+a;if(blocked.contains(j)||done.contains(j))continue;final len=distance(point(i),point(j));
    if((z[b][a]-z[y][x]).abs()>len*.7002)continue;
    final g=costs[i]!+len;if(g>=(costs[j]??double.infinity))continue;
    costs[j]=g;parent[j]=i;final h=exits.map((k)=>distance(point(k),point(j))).reduce(m.min);queue.add((j,g+h));
   }
  }return [];
 }
}
class Field extends StatefulWidget{const Field({super.key});@override State<Field> createState()=>FieldState();}
class FieldState extends State<Field>{
 Database? db;Region? region;Point? location;List<Point> crumbs=[];List<int> route=[];StreamSubscription<Position>? stream;
 bool tracking=false,back=false,live=false,emergency=false,busy=false;int next=0;String status='Opening field journal';
 @override void initState(){super.initState();open();}
 Future<void> open()async{try{db=await openDatabase('ridgeway.db',version:1,onCreate:(d,_)async{await d.execute('CREATE TABLE pack(id INTEGER PRIMARY KEY, body TEXT)');await d.execute('CREATE TABLE trail(id INTEGER PRIMARY KEY, lat REAL, lon REAL)');});
 final saved=await db!.query('pack');region=Region(jsonDecode(saved.isEmpty?await rootBundle.loadString('assets/training.json'):saved.first['body'] as String));crumbs=(await db!.query('trail',orderBy:'id')).map((v)=>(lat:v['lat'] as double,lon:v['lon'] as double)).toList();if(region!.data['demo']==true)location=region!.point(0);status='Region available offline';}catch(e){status='Could not open journal: $e';}if(mounted)setState((){});}
 @override void dispose(){stream?.cancel();super.dispose();}
 Future<void> fix(Point p)async{final r=region!;location=p;
 if(tracking&&(crumbs.isEmpty||distance(crumbs.last,p)>=10)){await db!.insert('trail',{'lat':p.lat,'lon':p.lon});crumbs.add(p);}
 if(back&&distance(p,crumbs[next])<12){if(next>0){next--;}else{back=false;status='Reached first recorded point';}}
 if(emergency){final i=r.cell(p);if(i==null){route=[];status='Outside pack coverage';}else if(route.isEmpty||!route.contains(i)){route=r.route(i);status=route.isEmpty?'No feasible route in pack':'Route to mapped exit';}else{route=route.sublist(route.indexOf(i));}}
 if(mounted)setState((){});}
 Future<void> gps()async{if(region!.data['demo']==true){await fix(region!.point(((region!.cell(location!)??0)+1)%(region!.rows*region!.cols)));return;}
 if(live)return;if(!await Geolocator.isLocationServiceEnabled()){throw StateError('Enable device location');}
 var perm=await Geolocator.checkPermission();if(perm==LocationPermission.denied)perm=await Geolocator.requestPermission();
 if(perm==LocationPermission.denied||perm==LocationPermission.deniedForever)throw StateError('Location permission required');
 live=true;status='Waiting for satellite fix';stream=Geolocator.getPositionStream(locationSettings:AndroidSettings(accuracy:LocationAccuracy.best,distanceFilter:3,foregroundNotificationConfig:const ForegroundNotificationConfig(notificationTitle:'Ridgeway tracking',notificationText:'Location active for this hike',enableWakeLock:true))).asyncMap((v)async{if(v.accuracy>25){setState(()=>status='Weak GNSS · last accepted fix shown');return;}status='GNSS ±${v.accuracy.round()} m';await fix((lat:v.latitude,lon:v.longitude));}).listen((_){},onError:(e){if(mounted)setState(()=>status='Location error: $e');});}
 Future<void> area()async{
 String lat=location?.lat.toString()??'',lon=location?.lon.toString()??'',radius='1';
 final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Download hiking area'),content:Column(mainAxisSize:MainAxisSize.min,children:[for(final item in [('Latitude',lat),('Longitude',lon),('Radius (km)',radius)])TextFormField(initialValue:item.$2,keyboardType:const TextInputType.numberWithOptions(decimal:true,signed:true),decoration:InputDecoration(labelText:item.$1),onChanged:(v){if(item.$1=='Latitude'){lat=v;}else if(item.$1=='Longitude'){lon=v;}else{radius=v;}})]),actions:[TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Download'))]));
 if(ok!=true)return;
 if(tracking||crumbs.isNotEmpty)throw StateError('Pause tracking and clear the saved trail before replacing the region');
 setState(()=>status='Downloading map and elevation…');
 final body=await downloadArea(double.parse(lat),double.parse(lon),double.parse(radius));final r=Region(jsonDecode(body));await stream?.cancel();await db!.insert('pack',{'id':1,'body':body},conflictAlgorithm:ConflictAlgorithm.replace);region=r;location=null;live=tracking=back=emergency=false;route=[];status='Offline region ready';
 }
 Future<void> vectorMap()async{
 final r=region!;
 List<double> xy(Point p)=>[p.lon,p.lat];
 final features=[...(r.data['features'] as List? ?? []),for(final group in [('track',crumbs),('exit',route.map(r.point).toList())])if(group.$2.length>1){'type':'Feature','properties':{'kind':group.$1},'geometry':{'type':'LineString','coordinates':group.$2.map(xy).toList()}},if(location!=null){'type':'Feature','properties':{'kind':'position'},'geometry':{'type':'Point','coordinates':xy(location!)}}];
 final payload=jsonEncode({'geo':{'type':'FeatureCollection','features':features},'bounds':[xy(r.point(0)),xy(r.point(r.cols*r.rows-1))]});
 final controller=WebViewController();await controller.setJavaScriptMode(JavaScriptMode.unrestricted);await controller.setNavigationDelegate(NavigationDelegate(onPageFinished:(_)async{await controller.runJavaScript('render('+payload+')');}));await controller.loadFlutterAsset('assets/map.html');if(!mounted)return;await Navigator.push(context,MaterialPageRoute<void>(builder:(c)=>Scaffold(appBar:AppBar(title:const Text('Offline map')),body:WebViewWidget(controller:controller),bottomNavigationBar:const SafeArea(child:Text('© OpenStreetMap contributors · Elevation: AWS Terrain Tiles')))));
 }
 Future<void> install()async{String url='';final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Install region pack'),content:TextField(onChanged:(v)=>url=v,decoration:const InputDecoration(labelText:'HTTPS pack URL')),actions:[TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Download'))]));if(ok!=true)return;
 final uri=Uri.parse(url.trim());if(uri.scheme!='https')throw const FormatException('HTTPS required');final client=HttpClient()..connectionTimeout=const Duration(seconds:20);try{final response=await(await client.getUrl(uri)).close();if(response.statusCode!=200)throw HttpException('Download failed');final bytes=<int>[];await for(final chunk in response){bytes.addAll(chunk);if(bytes.length>12000000)throw const FormatException('Pack too large');}final body=utf8.decode(bytes),r=Region(jsonDecode(body));if(crumbs.isNotEmpty)throw StateError('Clear the current trail before replacing its pack');await stream?.cancel();await db!.insert('pack',{'id':1,'body':body},conflictAlgorithm:ConflictAlgorithm.replace);region=r;location=r.data['demo']==true?r.point(0):null;route=[];live=tracking=back=emergency=false;status='Pack installed';}finally{client.close(force:true);}}
 Future<void> act(Future<void> Function() f)async{if(busy)return;setState(()=>busy=true);try{await f();}catch(e){status=e.toString();}finally{if(mounted)setState(()=>busy=false);}}
 @override Widget build(BuildContext context){final r=region,p=location;
 Widget button(String label,IconData icon,Future<void> Function() action)=>OutlinedButton.icon(onPressed:busy?null:()=>act(action),icon:Icon(icon),label:Text(label));
 return Scaffold(appBar:AppBar(title:const Text('Ridgeway'),actions:[IconButton(tooltip:'Install pack',onPressed:r==null?null:()=>act(install),icon:const Icon(Icons.download))]),body:r==null?Center(child:Text(status)):SafeArea(child:ListView(padding:const EdgeInsets.all(16),children:[Text(r.data['name'],style:Theme.of(context).textTheme.headlineSmall),Text(status),const SizedBox(height:12),ClipRRect(borderRadius:BorderRadius.circular(18),child:AspectRatio(aspectRatio:1.25,child:InteractiveViewer(maxScale:8,child:CustomPaint(painter:Terrain(r,p,crumbs,route))))),const Text('Teal  track     Amber  exit route     Blue  water     White  exit'),const SizedBox(height:12),Wrap(spacing:8,children:[
 button('Download area',Icons.download_for_offline,area),if(r.data['demo']!=true)button('Street & trail map',Icons.map,vectorMap),
 button(r.data['demo']==true?'Walk demo':'Locate me',Icons.my_location,gps),
 button(tracking?'Pause recording':'Record trail',Icons.route,()async{tracking=!tracking;if(!tracking&&live){await stream?.cancel();live=false;}if(tracking){back=false;if(!live&&r.data['demo']!=true)await gps();if(location!=null)await fix(location!);}}),
 button('Backtrack',Icons.undo,()async{if(crumbs.isEmpty)throw StateError('Record a trail first');tracking=emergency=false;route=[];back=true;next=crumbs.length-1;status='Follow recorded trail';}),
 button('Find exit',Icons.signpost,()async{if(p==null)throw StateError('Acquire location first');emergency=true;back=false;route=[];await fix(p);}),
 button('Clear trail',Icons.delete_outline,()async{final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Delete recorded trail?'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Keep')),TextButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Delete'))]));if(yes==true){tracking=back=false;await db!.delete('trail');crumbs=[];}})]),
 Text('${crumbs.length} breadcrumbs saved'),if(back&&p!=null)Text('Point ${next+1} · ${distance(p,crumbs[next]).round()} m · bearing ${((Geolocator.bearingBetween(p.lat,p.lon,crumbs[next].lat,crumbs[next].lon)+360)%360).round()}°'),
 if(p!=null&&r.cell(p)!=null)Text('Elevation · ${r.z[r.cell(p)!~/r.cols][r.cell(p)!%r.cols]} m'),if(route.isNotEmpty)Text('Exit route · ${List.generate(route.length-1,(i)=>distance(r.point(route[i]),r.point(route[i+1]))).fold<double>(0,(a,b)=>a+b).round()} m'),
 const Divider(),Text('Mapped water',style:Theme.of(context).textTheme.titleLarge),if(p!=null)...(r.water.toList()..sort((a,b)=>distance(p,r.point(a['cell'])).compareTo(distance(p,r.point(b['cell']))))).map((w)=>ListTile(leading:const Icon(Icons.water_drop_outlined),title:Text(w['name']),subtitle:Text('${distance(p,r.point(w['cell'])).round()} m · mapped feature'))),const Text('Routes use cached terrain. Actual conditions and water quality are unverified.')])));}
}
class Terrain extends CustomPainter{
 final Region r;final Point? p;final List<Point> track;final List<int> route;Terrain(this.r,this.p,this.track,this.route);
 @override void paint(Canvas c,Size s){final w=s.width/r.cols,h=s.height/r.rows;Offset pos(int i)=>Offset((i%r.cols+.5)*w,(r.rows-i~/r.cols-.5)*h);final pen=Paint();
 for(var y=0;y<r.rows;y++){for(var x=0;x<r.cols;x++){final i=y*r.cols+x,v=(r.z[y][x] as num).toDouble();pen.color=r.blocked.contains(i)?const Color(0xff48584f):Color.lerp(const Color(0xffb6ceaa),const Color(0xff688b74),(.5+.45*m.sin(v/30)))!;c.drawRect(Rect.fromCenter(center:pos(i),width:w+.4,height:h+.4),pen);}}
 void line(List<int> points,Color color){pen..color=color..strokeWidth=3;for(var j=1;j<points.length;j++){c.drawLine(pos(points[j-1]),pos(points[j]),pen);}}
 line(track.map(r.cell).whereType<int>().toList(),Colors.teal.shade900);line(route,Colors.amber);for(final i in r.exits){c.drawCircle(pos(i),4,pen..color=Colors.white);}for(final v in r.water){c.drawCircle(pos(v['cell']),4,pen..color=Colors.blue);}final i=p==null?null:r.cell(p!);if(i!=null){c.drawCircle(pos(i),8,pen..color=Colors.white);c.drawCircle(pos(i),5,pen..color=Colors.deepOrange);}}
 @override bool shouldRepaint(Terrain other)=>true;
}
