import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

Future<String> downloadArea(double lat,double lon,double radius) async {
  if(!lat.isFinite||!lon.isFinite||!radius.isFinite||lat.abs()>80||lon.abs()>179||radius<0.25||radius>3) {
    throw const FormatException('Choose 0.25–3 km and valid coordinates inside coverage');
  }
  final step=radius/111.32/20;
  final west=lon-20*step/math.cos(lat*math.pi/180);
  final south=lat-20*step;
  final cols=(40/math.cos(lat*math.pi/180)).ceil()+1;
  const rows=41;
  final north=south+40*step,east=west+(cols-1)*step;
  final bbox='$south,$west,$north,$east';
  final client=HttpClient()..connectionTimeout=const Duration(seconds:20);
  Future<List<int>> fetch(Uri uri) async {
    final req=await client.getUrl(uri);req.headers.set('User-Agent','Ridgeway-Educational-Navigator/1.0');
    final res=await req.close().timeout(const Duration(seconds:60));
    if(res.statusCode!=200)throw HttpException('Region provider returned ${res.statusCode}');
    final bytes=<int>[];await for(final chunk in res.timeout(const Duration(seconds:30))){bytes.addAll(chunk);if(bytes.length>16000000)throw const FormatException('Region too large');}return bytes;
  }
  try{
    final query='[out:json][timeout:40];(way["highway"]($bbox);way["waterway"]($bbox);way["natural"~"^(water|cliff)$"]($bbox);node["natural"="spring"]($bbox););out geom;';
    final osm=jsonDecode(utf8.decode(await fetch(Uri.https('overpass-api.de','/api/interpreter',{'data':query}))));
    if(osm['remark']!=null)throw StateError('Incomplete OpenStreetMap response');
    final water=<Map>[],features=<Map>[],exits=<int>{},blocked=<int>{};
    int? cell(double y,double x){final a=((x-west)/step).round(),b=((y-south)/step).round();return a<0||b<0||a>=cols||b>=rows?null:b*cols+a;}
    for(final e in osm['elements']){
      final tags=e['tags'] as Map, geometry=e['geometry']??[e];
      final coords=<List<double>>[for(final q in geometry) [(q['lon'] as num).toDouble(),(q['lat'] as num).toDouble()]];
      if(coords.isEmpty)continue;
      final road=tags['highway']!=null, cliff=tags['natural']=='cliff';
      final kind=road?'road':cliff?'cliff':'water';
      features.add({'type':'Feature','properties':{'kind':kind},'geometry':{'type':coords.length==1?'Point':'LineString','coordinates':coords.length==1?coords.first:coords}});
      final cells=<int>{};
      for(var i=0;i<coords.length;i++){
        final a=coords[i],b=coords[math.min(i+1,coords.length-1)];
        final count=math.max(1,(2*math.max((b[0]-a[0]).abs(),(b[1]-a[1]).abs())/step).ceil());
        for(var k=0;k<=count;k++){final t=k/count,j=cell(a[1]+(b[1]-a[1])*t,a[0]+(b[0]-a[0])*t);if(j!=null)cells.add(j);}
      }
      if(kind=='water'&&cells.isNotEmpty)water.add({'name':tags['name']??tags['waterway']??tags['natural'],'cell':cells.first});
      if(cliff||(!road&&coords.length>1))blocked.addAll(cells);
      if(road&&['residential','tertiary','secondary','primary','unclassified','living_street'].contains(tags['highway'])&&!['private','no'].contains(tags['access'])&&!['private','no'].contains(tags['foot']))exits.addAll(cells);
    }
    if(exits.difference(blocked).isEmpty)throw StateError('No mapped road exit in this area. Expand or move the region.');
    final elevations=await loadElevation(south,west,step,rows,cols,fetch);
    return jsonEncode({'name':'Field region · ${lat.toStringAsFixed(3)}, ${lon.toStringAsFixed(3)}','lat':south,'lon':west,'step':step,'z':elevations,'blocked':blocked.toList(),'exits':exits.toList(),'water':water,'features':features});
  }finally{client.close(force:true);}
}
Future<List<List<int>>> loadElevation(double south,double west,double step,int rows,int cols,Future<List<int>> Function(Uri) fetch) async{
 final cache=<String,img.Image>{};final grid=<List<int>>[];
 for(var y=0;y<rows;y++){final row=<int>[];grid.add(row);
 for(var x=0;x<cols;x++){final lat=(south+y*step)*math.pi/180,lon=west+x*step;
 final px=((lon+180)/360*1048576).floor(),py=((1-math.log(math.tan(lat)+1/math.cos(lat))/math.pi)/2*1048576).floor();
 final key='${px~/256}/${py~/256}';if(!cache.containsKey(key)){final bytes=await fetch(Uri.parse('https://s3.amazonaws.com/elevation-tiles-prod/terrarium/12/$key.png'));cache[key]=img.decodePng(Uint8List.fromList(bytes))??(throw const FormatException('Unreadable elevation tile'));}
 final pixel=cache[key]!.getPixel(px%256,py%256);row.add((pixel.r*256+pixel.g+pixel.b/256-32768).round());
 }}return grid;
}
